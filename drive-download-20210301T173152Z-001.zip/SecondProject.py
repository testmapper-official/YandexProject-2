import pygame
import os
import sys
import math
import random

FPS = 60
LEVEL = 1

# Конвертация карты из файла в объект Python
def load_level(filename):
    try:
        filename = "data/" + filename
        # читаем уровень, убирая символы перевода строки
        with open(filename, 'r') as mapFile:
            level_map = [line.strip() for line in mapFile]

        # и подсчитываем максимальную длину    
        max_width = max(map(len, level_map))    

        # дополняем каждую строку пустыми клетками ('.')    
        return list(map(lambda x: x.ljust(max_width, '.'), level_map))
    except:
        print("Ошибка")
        sys.exit()

# Создание окна
pygame.init()
screen = pygame.display.set_mode((800, 600))#, pygame.FULLSCREEN)
width = pygame.display.get_surface().get_size()[0]
height = pygame.display.get_surface().get_size()[1]
all_sprites = pygame.sprite.Group()
clock = pygame.time.Clock()
# основной персонаж
player = None

# группы спрайтов
all_sprites = pygame.sprite.Group()
tiles_group = pygame.sprite.Group()
player_group = pygame.sprite.Group()
units_group = pygame.sprite.Group()
bullets_group = pygame.sprite.Group()
barrels_group = pygame.sprite.Group()
block_group = pygame.sprite.RenderUpdates()

#Загрузка изобажения
def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    # если файл не существует, то выходим
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image

koefficient = 1

#Словарь изображений
tile_images = {
    'wall': load_image('Tile_Wall.png'),
    'empty': load_image('empty.png'),
    'column': load_image('Tile_Column.png'),
    'ground': load_image('Tile_PurpleBrick.png'),
    'barrel': pygame.transform.scale(load_image('barrel.png'), (50, 50))
    }
player_image = pygame.transform.scale(load_image('soldier1.png'), (35 * koefficient, 35  * koefficient))

for i in tile_images:
    size = tile_images[i].get_size()
    tile_images[i] = pygame.transform.scale(tile_images[i], (size[0] * koefficient, size[1]  * koefficient))

tile_width = tile_height = 50 * koefficient

# Камера
class Camera:
    # зададим начальный сдвиг камеры
    def __init__(self):
        self.dx = 0
        self.dy = 0
        
    # сдвинуть объект obj на смещение камеры
    def apply(self, obj):
        obj.rect.x = (obj.rect.x + self.dx)
        obj.rect.y = (obj.rect.y + self.dy)
    
    # позиционировать камеру на объекте target
    def update(self, target):
        self.dx = -(target.rect.x + target.rect.w // 2 - width // 2)
        self.dy = -(target.rect.y + target.rect.h // 2 - height // 2)

# Плитка
class Tile(pygame.sprite.Sprite):
    def __init__(self, tile_type, pos_x, pos_y):
        if tile_type in {'wall', 'column'}: # Непроходимые текстуры
            super().__init__(tiles_group, all_sprites, block_group)
        else: # Проходимые текстуры
            super().__init__(tiles_group, all_sprites)
        self.radius = tile_height * 0.6
        self.image = tile_images[tile_type]
        self.rect = self.image.get_rect().move(
            tile_width * pos_x, tile_height * pos_y)

    def update(self, screen, fow=None):
        pass

# Бочка, главная цель стрелка
class Barrel(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(tiles_group, all_sprites, barrels_group)
        self.radius = tile_height * 0.6
        self.image = tile_images['barrel']
        self.rect = self.image.get_rect().move(
            tile_width * pos_x, tile_height * pos_y)

    def update(self, screen, fow=None):
        pass

#Игрок-стрелок
class Player(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(player_group, all_sprites, units_group)
        self.image = player_image
        self.rect = self.image.get_rect().move(
            tile_width * pos_x + 8, tile_height * pos_y  + 8).copy()
        self.x, self.y = self.rect.center
        self.radius = 10
        self.center_image = (self.rect.size[0] // 2, self.rect.size[1] * 0.7)
        self.angle = -90

    # Часть функции reangle, изменяет холст стрелка, поворачивая
    def rotate(self, img, pos, angle):
        w, h = img.get_size()
        img2 = pygame.Surface((w*2, h*2), pygame.SRCALPHA)
        img2.blit(img, (w-pos[0], h-pos[1]))
        return pygame.transform.rotate(img2, angle)

    # Поворот стрелка, его пистолет
    def reangle(self, pos):
        x2, y2 = pos
        self.x, self.y = self.rect.center
        angle = int(math.degrees(math.atan2(y2 - self.y, x2 - self.x)))
        if angle != self.angle:
            self.angle = angle
            self.image = self.rotate(player_image, self.center_image, -self.angle - 90)
            self.rect = self.image.get_rect(center=self.rect.center)

    # Передвижение
    def move(self, x, y):
        image = pygame.Surface((16, 16))
        x /= FPS
        y /= FPS
        rect = image.get_rect(center=self.rect.center).move(tile_width * x, tile_height * y)
        collided = any(rect.colliderect(block.rect)
               for block in block_group if self != block)
        collided2 = any(rect.colliderect(barrel.rect)
               for barrel in barrels_group if self != barrel)
        if not (collided or collided2):
            self.rect = self.rect.move(tile_width * x, tile_height * y)

    def update(self, screen, fow=None):
        pass

#Пуля стрелка
class Bullet(pygame.sprite.Sprite):
    def __init__(self, x, y, angle):
        super().__init__(all_sprites, bullets_group)
        print(angle)
        self.image = pygame.surface.Surface((24, 24), pygame.SRCALPHA)
        ay = math.sin(math.radians(angle))
        ax = math.cos(math.radians(angle))
        self.rect = self.image.get_rect().move(
            x + 20 * ax - 4, y + 20 * ay - 4).copy()
        self.radius = 10
        self.angle = angle
        print(int(x - 8 * ax), int(y - 8 * ay))
        print(int(x + 8 * ax), int(y + 8 * ay))
        pygame.draw.line(self.image, 'yellow', (12, 12), (12 + 12 * ax, 12 + 12 * ay), 3)

    # Проверка колизии пули с объектами
    def update(self):
        rect = self.rect.move(
            1500 * math.cos(math.radians(self.angle)) / FPS, 1500 * math.sin(math.radians(self.angle)) / FPS)
        collided = any(rect.colliderect(block.rect)
               for block in block_group if self != block)
        if not collided:
            for barrel in barrels_group:
                if rect.colliderect(barrel.rect) and self != barrel:
                    self.kill()
                    barrel.kill()
                    break
            if self is not None:
                self.rect = rect
        else:
            self.kill()
    
#Генерация уровня
def generate_level(level):
    new_player, x, y = None, None, None
    for y in range(len(level)):
        for x in range(len(level[y])):
            if level[y][x] == '.':
                Tile('ground', x, y)
            elif level[y][x] == '#':
                Tile('wall', x, y)
            elif level[y][x] == '@':
                Tile('column', x, y)
            elif level[y][x] == 'H':
                Tile('ground', x, y)
                new_player = Player(x, y)
            elif level[y][x] == 'B':
                Tile('ground', x, y)
                Barrel(x, y)
            elif level[y][x] == '!':
                Tile('ground', x, y)
    # вернем игрока, а также размер поля в клетках            
    return new_player, x, y

#Завершение работы
def terminate():
    pygame.quit()
    sys.exit()

#Основное окно
def final_screen():
    global LEVEL
    maps = load_level(f'map{LEVEL}.txt')
    player, level_x, level_y = generate_level(maps)
    camera = Camera()
    fog_of_war = pygame.Rect(0, 0, width, height)
    drawing_tiles = pygame.sprite.Group()
    drawing_units = pygame.sprite.Group()
    while True:
        pygame.display.set_caption('Shooter [FPS: {}]'.format(int(
                clock.get_fps())))
        if len(barrels_group) == 0: # Завершаем уровень, если нет бочек
            LEVEL += 1
            all_sprites.empty()
            tiles_group.empty()
            player_group.empty()
            units_group.empty()
            bullets_group.empty()
            barrels_group.empty()
            block_group.empty()
            drawing_tiles.empty()
            drawing_units.empty()
            if LEVEL <= 3:
                return final_screen()
            else:
                LEVEL = 1
                return epilogue()
        for event in pygame.event.get(): # Управление игрока
            if event.type == pygame.QUIT:
                terminate()
            if event.type == pygame.MOUSEMOTION:
                player.reangle(event.pos)
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1: # Создание пули
                    Bullet(player.x, player.y, player.angle)
        keys = pygame.key.get_pressed()
        if keys[pygame.K_w]:
            player.move(0, -5)
        if keys[pygame.K_a]:
            player.move(-5, 0)
        if keys[pygame.K_s]:
            player.move(0, 5)
        if keys[pygame.K_d]:
            player.move(5, 0)
        # изменяем ракурс камеры
        camera.update(player); 
        # обновляем положение всех спрайтов
        for sprite in all_sprites:
              camera.apply(sprite)
        screen.fill((0, 0, 0))
        if True: # Отображаем только те спрайты, которые на экране
            drawing_tiles.empty()
            [sprite.add(drawing_tiles) for sprite in tiles_group
                                             if fog_of_war.colliderect(sprite.rect)]
            drawing_units.empty()
            [sprite.add(drawing_units) for sprite in units_group
                                             if fog_of_war.colliderect(sprite.rect)]
            
        drawing_tiles.draw(screen)
        bullets_group.update()
        drawing_units.draw(screen)
        bullets_group.draw(screen)
        clock.tick(FPS)
        pygame.display.flip()

# Финальный экран с поздравлениями
def epilogue():
    text1 = ["Поздравляем, вы прошли игру!"]
    text2 = ["Нажмите еще раз, чтобы вернуться в главное меню."]
    screen.fill((0, 0, 0))
    font = pygame.font.Font(None, 32)
    text_coord = 50
    for line in text1:
        string_rendered = font.render(line, 1, pygame.Color('white'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 125
        intro_rect.y = 75
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)
    for line in text2:
        string_rendered = font.render(line, 1, pygame.Color('white'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 75
        intro_rect.y = 135
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                return start_screen()
        pygame.display.flip()
        clock.tick(FPS)

# Главное меню
def start_screen():
    title = pygame.transform.scale(load_image('title2.png', -1), (width, height))
    fon = pygame.transform.scale(load_image('mainmenu.jpg'), (int(height * 1.910828) * 5 // 4, height))
    grandfather = pygame.transform.scale(load_image('деда.png'), (int(height // 2 * 2.6818182), height // 2))
    screen.blit(fon, (0, 0))
    xf, yf = 10, 0
    xs, ys = 0.021, 0.08
    xfon = -650
    xknock = 10.08
    screen.blit(grandfather, (0, height // 2))
    string_rendered = None
    intro_rect = None
    pygame.display.set_caption('Shooter')
    text1 = ["Нажмите кнопку мыши, чтобы начать"]
    text2 = ["Цель игры: уничтожить все бочки"]
    font = pygame.font.Font(None, 32)
    text_coord = 50
    for line in text1:
        string_rendered1 = font.render(line, 1, pygame.Color('pink'))
        intro_rect1 = string_rendered1.get_rect()
        text_coord += 10
        intro_rect1.top = text_coord
        intro_rect1.x = 50
        intro_rect1.y = 190
        text_coord += intro_rect1.height
    font = pygame.font.Font(None, 48)
    for line in text2:
        string_rendered2 = font.render(line, 1, pygame.Color('dark green'))
        intro_rect2 = string_rendered2.get_rect()
        text_coord += 10
        intro_rect2.top = text_coord
        intro_rect2.x = 150
        intro_rect2.y = 450
        text_coord += intro_rect2.height
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN and xfon >= 0 and xf <= 2: 
                return final_screen()
        if xf >= 2:
            xs = -0.021
        elif xf <= 1:
            xs = 0.021
        xf += xs
        if yf >= 4: 
            ys = -0.08
        elif yf <= 0:
            ys = 0.08
        yf += ys
        if xfon < 0:
            xfon += xknock
            xknock = max(0.2, xknock - 0.079)
        screen.blit(fon, (xfon, 0))
        screen.blit(title, (0, yf ** 2 // 2 - max(2, xf) ** 3 * 2))
        screen.blit(grandfather, (0 + xf ** 4 // 2, height // 2 + yf ** 2 // 2))
        if xfon >= 0 and xf <= 2.25:
            screen.blit(string_rendered1, intro_rect1)
        else:
            screen.blit(string_rendered2, intro_rect2)
        pygame.display.flip()
        clock.tick(FPS)

if __name__ == '__main__':
    start_screen()
